<?php

return [
    'smtp_host' => 'smtp.gmail.com',
    'smtp_username' => 'rohitbgmi370@gmail.com',
    'smtp_password' => 'tuoy gxde iyzl eorc'
];

?>